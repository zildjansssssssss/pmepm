<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>
<?php include 'includes/sidebar.php'; ?>
                            <div class="sb-sidenav-menu-heading">Future Features</div>
                            <a class="nav-link" href="charts.html">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                Charts
                            </a>
                            <a class="nav-link" href="tables.html">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Tables
                            </a>
                        </div>
                    </div>
                    
                    <div id="layoutSidenav_content">
                <main>
                    
                        
                            
                         
                        
                </main>
                
                <?php include 'includes/footer.php'; ?>
                <?php include 'includes/script.php'; ?>
